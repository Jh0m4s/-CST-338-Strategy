package Ability;
import Monster.*;
/**
 * Name: Joey Thomas
 * Date: 3/1/2019
 * Explanation: A Interface that doesnt do anything but help link that is called Ability.Ability.
 */
public interface Ability {

}
